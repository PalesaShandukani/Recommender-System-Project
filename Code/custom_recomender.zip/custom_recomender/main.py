import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from tqdm import tqdm
import kagglehub
import pickle
import os
import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")


class CustomRecommender:
    def __init__(self, n_users=None, n_items=None, n_factors=10, learning_rate=0.01, reg_param=0.01, n_epochs=50):
        self.n_users = n_users
        self.n_items = n_items
        self.n_factors = n_factors
        self.lr = learning_rate
        self.reg = reg_param
        self.epochs = n_epochs
        self.loss_history = []

        if n_users is not None and n_items is not None:
            self.P = np.random.normal(scale=0.1, size=(n_users, n_factors))
            self.Q = np.random.normal(scale=0.1, size=(n_items, n_factors))
            self.b_u = np.zeros(n_users)
            self.b_i = np.zeros(n_items)
            self.mu = 0

    def fit(self, ratings):
        self.train_matrix = ratings.values.astype(np.float32)
        self.n_users, self.n_items = self.train_matrix.shape

        self.mu = np.nanmean(self.train_matrix)
        self.b_u = np.zeros(self.n_users)
        self.b_i = np.zeros(self.n_items)
        self.P = np.random.normal(0, 0.1, (self.n_users, self.n_factors))
        self.Q = np.random.normal(0, 0.1, (self.n_items, self.n_factors))

        self.non_zero = [
            (i, j, self.train_matrix[i, j])
            for i in range(self.n_users)
            for j in range(self.n_items)
            if np.isfinite(self.train_matrix[i, j]) and self.train_matrix[i, j] != 0
        ]

        threshold = 3  # example threshold to consider rating as positive (liked)

        for epoch in range(self.epochs):
            np.random.shuffle(self.non_zero)
            with tqdm(self.non_zero, desc=f"Epoch {epoch + 1}/{self.epochs}") as pbar:
                for i, j, r in pbar:
                    self._sgd_step(i, j, r)

            loss = self.mse()
            self.loss_history.append(loss)

            # Calculate accuracy
            correct = 0
            total = 0
            for i, j, r in self.non_zero:
                pred = self.predict_single(i, j)
                # Convert both prediction and true rating to binary liked/not liked
                pred_binary = pred >= threshold
                true_binary = r >= threshold
                if pred_binary == true_binary:
                    correct += 1
                total += 1
            accuracy = correct / total if total > 0 else 0

            print(f"Epoch {epoch + 1}, Loss: {loss:.6f}, Accuracy: {accuracy:.4f}")

            if not np.isfinite(loss):
                print("Loss became NaN or Inf — stopping early.")
                break

    def plot_training_rmse(self):
        rmses = np.sqrt(self.loss_history)
        plt.figure(figsize=(8, 5))
        plt.plot(range(1, len(rmses) + 1), rmses, marker='o')
        plt.title("Training RMSE Over Epochs")
        plt.xlabel("Epoch")
        plt.ylabel("RMSE")
        plt.grid(True)
        plt.show()

    def _sgd_step(self, i, j, r):
        pred = self.predict_single(i, j)
        e = r - pred
        e = np.clip(e, -10, 10)

        self.b_u[i] += self.lr * (e - self.reg * self.b_u[i])
        self.b_i[j] += self.lr * (e - self.reg * self.b_i[j])

        P_i = self.P[i, :].copy()
        Q_j = self.Q[j, :].copy()

        self.P[i, :] += self.lr * (e * Q_j - self.reg * P_i)
        self.Q[j, :] += self.lr * (e * P_i - self.reg * Q_j)

        self.P[i, :] = np.clip(self.P[i, :], -5, 5)
        self.Q[j, :] = np.clip(self.Q[j, :], -5, 5)

    def predict_single(self, i, j):
        return self.mu + self.b_u[i] + self.b_i[j] + np.dot(self.P[i, :], self.Q[j, :])

    def predict(self):
        return np.array([
            [self.predict_single(i, j) for j in range(self.n_items)]
            for i in range(self.n_users)
        ])

    def mse(self):
        errors = []
        for i, j, r in self.non_zero:
            pred = self.predict_single(i, j)
            if np.isfinite(pred):
                errors.append((r - pred) ** 2)
        return np.mean(errors) if errors else float('nan')

    def recommend(self, user_id, n=5):
        if user_id >= self.P.shape[0]:
            return np.array([])
        scores = self.mu + self.b_u[user_id] + self.b_i + np.dot(self.P[user_id, :], self.Q.T)
        valid_scores = np.nan_to_num(scores, nan=-np.inf)
        top_items = np.argsort(-valid_scores)[:n]
        return top_items

    def save(self, filepath):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'wb') as f:
            pickle.dump({
                'P': self.P,
                'Q': self.Q,
                'b_u': self.b_u,
                'b_i': self.b_i,
                'mu': self.mu,
                'n_factors': self.n_factors,
                'lr': self.lr,
                'reg': self.reg
            }, f)

    @classmethod
    def load(cls, filepath):
        with open(filepath, 'rb') as f:
            data = pickle.load(f)
        model = cls(
            n_factors=data['n_factors'],
            learning_rate=data['lr'],
            reg_param=data['reg']
        )
        model.P = data['P']
        model.Q = data['Q']
        model.b_u = data['b_u']
        model.b_i = data['b_i']
        model.mu = data['mu']
        model.n_users = model.P.shape[0]
        model.n_items = model.Q.shape[0]
        return model

    def _plot_loss(self):
        plt.figure(figsize=(8, 5))
        plt.plot(range(1, len(self.loss_history) + 1), self.loss_history, marker='o')
        plt.title("Training Loss Over Epochs")
        plt.xlabel("Epoch")
        plt.ylabel("Loss (MSE)")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def visualize_predictions(model, test_matrix):
        test_errors = []
        predictions = []
        actuals = []

        non_zero = [(i, j, test_matrix.iloc[i, j])
                    for i in range(test_matrix.shape[0])
                    for j in range(test_matrix.shape[1])
                    if test_matrix.iloc[i, j] > 0]

        for i, j, r in non_zero:
            prediction = model.predict_single(i, j)
            test_errors.append((r - prediction) ** 2)
            predictions.append(prediction)
            actuals.append(r)

        plt.figure(figsize=(6, 6))
        sns.scatterplot(x=actuals, y=predictions, alpha=0.5)
        plt.plot([min(actuals), max(actuals)], [min(actuals), max(actuals)], 'r--')
        plt.xlabel("Actual Ratings")
        plt.ylabel("Predicted Ratings")
        plt.title("Actual vs Predicted Ratings")
        plt.grid(True)
        plt.tight_layout()
        plt.show()


# Read the file
df = pd.read_csv('dq_recsys_challenge_2025(in).csv')

interaction_weights = {
    'DISPLAY': 1,
    'CLICK': 3,
    'CHECKOUT': 5
}

df['interaction_weight'] = df['interaction'].map(interaction_weights).fillna(0)

user_col = 'idcol'
item_col = 'item'
quantity_col = 'interaction_weight'

user_item_matrix = df.pivot_table(
    index=user_col,
    columns=item_col,
    values=quantity_col,
    aggfunc='sum',
    fill_value=0
)

user_ids = user_item_matrix.index.unique()
item_ids = user_item_matrix.columns.unique()
user_map = {user: idx for idx, user in enumerate(user_ids)}
item_map = {item: idx for idx, item in enumerate(item_ids)}
mapped_matrix = user_item_matrix.rename(index=user_map, columns=item_map)

train, test = train_test_split(mapped_matrix, test_size=0.2, random_state=42)


# Train and save model
model = CustomRecommender(n_factors=10, learning_rate=0.01, reg_param=0.01, n_epochs=50)
model.fit(train)
model.save('models/recommender.pkl')

model.plot_training_rmse()

# Load model
loaded_model = CustomRecommender.load('models/recommender.pkl')


# Evaluation
def evaluate(model, test_matrix, k=5):
    test_errors = []
    precisions = []
    recalls = []

    for user_idx in range(test_matrix.shape[0]):
        true_items = np.where(test_matrix.iloc[user_idx].values > 0)[0]
        if len(true_items) == 0:
            continue

        recommended = model.recommend(user_idx, n=k)
        if len(recommended) == 0:
            continue

        hits = len(set(recommended) & set(true_items))
        precision = hits / k
        recall = hits / len(true_items)

        precisions.append(precision)
        recalls.append(recall)

        for item_idx in true_items:
            prediction = model.predict_single(user_idx, item_idx)
            actual = test_matrix.iloc[user_idx, item_idx]
            test_errors.append((actual - prediction) ** 2)

    mse = np.mean(test_errors)
    rmse = np.sqrt(mse)
    avg_precision = np.mean(precisions)
    avg_recall = np.mean(recalls)

    print(f"Test MSE: {mse:.4f}")
    print(f"Test RMSE: {rmse:.4f}")
    print(f"Precision@{k}: {avg_precision:.4f}")
    print(f"Recall@{k}: {avg_recall:.4f}")

    CustomRecommender.visualize_predictions(model, test_matrix)

    return precisions, recalls, rmse


evaluate(loaded_model, test)

precisions, recalls, rmse = evaluate(loaded_model, test)

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
sns.histplot(precisions, bins=20, kde=True)
plt.title('Precision@5 Distribution')
plt.xlabel('Precision')
plt.ylabel('Number of Users')

plt.subplot(1, 2, 2)
sns.histplot(recalls, bins=20, kde=True)
plt.title('Recall@5 Distribution')
plt.xlabel('Recall')
plt.ylabel('Number of Users')

plt.tight_layout()
plt.show()

print(f"Overall RMSE: {rmse:.4f}")


# Recommendation function
def get_recommendations(original_user_id, n=5):
    if original_user_id not in user_map:
        print("User not found in training data. Returning popular items.")
        return user_item_matrix.sum().sort_values(ascending=False).head(n)

    user_idx = user_map[original_user_id]
    item_indices = loaded_model.recommend(user_idx, n)

    reverse_item_map = {v: k for k, v in item_map.items()}
    recommended_items = [reverse_item_map[idx] for idx in item_indices]

    descriptions = df[df['StockCode'].isin(recommended_items)][['StockCode', 'Description']].drop_duplicates()
    descriptions = descriptions.set_index('StockCode').loc[recommended_items]

    return descriptions
